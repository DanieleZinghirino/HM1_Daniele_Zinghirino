<?php 
    include 'database.php';
    header('Content-Type: application/json');

    $conn = mysqli_connect($database['host'], $database['user'], $database['password'], $database['name']);

    $query = "SELECT Nome, Cognome, Data_Nascita, Matricola FROM PT";
    $res = mysqli_query($conn, $query) or die(mysqli_error($conn));
    
    $postArray = array();
    while($entry = mysqli_fetch_assoc($res)) {
        $postArray[] = array('Nome' => $entry['Nome'], 
        'Cognome' => $entry['Cognome'], 
        'Matricola' => $entry['Matricola'],
        'Data_Nascita'=>$entry["Data_Nascita"]);
    }
    echo json_encode($postArray);
    
    exit; ?>