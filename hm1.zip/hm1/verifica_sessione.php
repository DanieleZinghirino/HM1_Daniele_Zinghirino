<?php
    require_once 'database.php';
    session_start();

    function verificaSessione() {
        if(isset($_SESSION['codice_fiscale'])) {
            return $_SESSION['codice_fiscale'];
        } else 
            return 0;
    }
?>