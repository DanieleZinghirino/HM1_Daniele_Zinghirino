<html>
    <head>
    <title>Daniele Zinghirino: Homework1</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Dela+Gothic+One&display=swap" rel="stylesheet">
    <link href="style/esercizi.css" rel="stylesheet" type="text/css">
    <script src="script/esercizi.js" defer></script>

    </head>
    <body>
        
    <div id="textP" class="hidden">
            <h1> I tuoi corsi preferiti: </h1>
        </div>
        <div id="preferiti">

        </div>


        <h1> Personalizza il tuo abbonamento scegliendo i tuoi esercizi preferiti: </h1>

        <div id="esercizi">

            <div id="muscoli">

                <div class="cont" data-nome="petto">

                    <div class="nome_muscolo">
                        <h2> Petto </h2>
                    </div>
                    <div class="casella">
                        <img src="immagini/casella_vuota.png" />
                    </div>

                </div>
                <div class="cont" data-nome="braccia">

                    <div class="nome_muscolo">
                        <h2> Braccia </h2>
                    </div>
                    <div class="casella">
                        <img src="immagini/casella_vuota.png" />
                    </div>
                </div>
                <div class="cont" data-nome="schiena">

                    <div class="nome_muscolo">
                        <h2> Schiena </h2>
                    </div>
                    <div class="casella">
                        <img src="immagini/casella_vuota.png" />
                    </div>
                </div>
                <div class="cont" data-nome="spalle">

                    <div class="nome_muscolo">
                        <h2> Spalle </h2>
                    </div>
                    <div class="casella">
                        <img src="immagini/casella_vuota.png" />
                    </div>
                </div>

                <div class="cont" data-nome="polpacci">

                    <div class="nome_muscolo">
                        <h2> Polpacci </h2>
                    </div>
                    <div class="casella">
                        <img src="immagini/casella_vuota.png" />
                    </div>
                </div>

                <div class="cont" data-nome="gambe">

                    <div class="nome_muscolo">
                        <h2> Gambe </h2>
                    </div>
                    <div class="casella">
                        <img src="immagini/casella_vuota.png" />
                    </div>
                </div>
                <div class="cont" data-nome="glutei">

                    <div class="nome_muscolo">
                        <h2> Glutei </h2>
                    </div>
                    <div class="casella">
                        <img src="immagini/casella_vuota.png" />
                    </div>
                </div>

                <div class="cont" data-nome="addominali">

                    <div class="nome_muscolo">
                        <h2> Addominali </h2>
                    </div>
                    <div class="casella">
                        <img src="immagini/casella_vuota.png" />
                    </div>
                </div>

            </div>

            <div id="api">

            </div>
        </div>
        <a href="home.php" class="button">Indietro</a>
    </body>
</html>