<?php 
require_once 'verifica_sessione.php';

if (!verificaSessione()){
    header("Location: login.php");
    exit;
}   

if (!empty($_POST["abbonamento"]) && !empty($_POST["pt"]) && !empty($_POST["scheda"])){
    $error=0;
    $conn = mysqli_connect($database['host'],$database['user'],$database['password'],$database['name']) or die(mysqli_error($conn));

    $cliente = $_SESSION["codice_fiscale"];
    $durata=$_POST["abbonamento"];
    $data_iscrizione=date ("Y/m/d");
    if(strcmp($durata,"1")===0){
        $prezzo=45;
        $data_scadenza = strtotime('+1 month', strtotime($data_iscrizione));
        $data_scadenza = date ('Y/m/d', $data_scadenza);}
    if(strcmp($durata,"3")===0){
        $prezzo=120;
        $data_scadenza = strtotime('+3 months', strtotime($data_iscrizione));
        $data_scadenza = date ('Y/m/d', $data_scadenza);}
    if(strcmp($durata,"6")===0){
        $prezzo=200;
        $data_scadenza = strtotime('+6 months', strtotime($data_iscrizione));
        $data_scadenza = date ('Y/m/d', $data_scadenza);}
    if(strcmp($durata,"12")===0){
        $prezzo=320;
        $data_scadenza = strtotime('+1 year', strtotime($data_iscrizione));
        $data_scadenza = date ('Y/m/d', $data_scadenza);}

    $pt = $_POST["pt"];
    $scheda = $_POST["scheda"];

    $query="DELETE FROM ALLENAMENTO WHERE Cliente = '$cliente' ";
    $ris = mysqli_query($conn, $query);

    do{
        $codice=rand(1,100000000);
        $query = "SELECT Cliente FROM ABBONAMENTO WHERE Codice = $codice ";
        $res = mysqli_query($conn, $query);
    }
    while(mysqli_num_rows($res) > 0);

    $query="INSERT INTO ABBONAMENTO(Codice, Cliente, Palestra, Prezzo, Durata, Data_Iscrizione, Data_Scadenza)
    VALUES ($codice,'$cliente',1 ,$prezzo, $durata,'$data_iscrizione','$data_scadenza')";

    $res = mysqli_query($conn, $query);
    if (!$res) {
        $error++;
        echo("<p class='errore'>");
        echo("Errore di connessione al database!");
        echo("</p>");}
    if($error==0){
        $query="INSERT INTO ALLENAMENTO(Palestra,Istruttore,Scheda,Cliente)
        VALUES(1,$pt,$scheda,'$cliente')";}
        $res = mysqli_query($conn, $query);
        if (!$res) {
            $error++;
            echo("<p class='errore'>");
            echo("Errore di connessione al database!");
            echo("</p>");}
        else { 
            header("Location: profile.php");
            exit;}


}
?>

<html>
    <head>
    <meta charset="utf-8">
    <title>Daniele Zinghirino: Homework1</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Dela+Gothic+One&display=swap" rel="stylesheet">
    <link href="style/form.css" rel="stylesheet" type="text/css">

        <title>Iscriviti</title>
    </head>
    <body>
        <main>
        <section>
            <h1>Scegli il tuo abbonamento</h1>
            <div id="allineamento">
            <form name='iscrizione' method='post'>
                <div>
                
                  <div id="abbonamento">
                        <h2> Scegli la durata del tuo abbonamento </h2>
                        1 mese <input type="radio" name="abbonamento" value="1"> 
                        3 mesi <input type="radio" name="abbonamento" value="3"> 
                        6 mesi <input type="radio" name="abbonamento" value="6"> 
                        12 mesi <input type="radio" name="abbonamento" value="12"> 
                 </div>

                 <div id="pt">
                    <h2> Scegli il tuo personal trainer </h2>
                    <?php 
                        $connessione1 = mysqli_connect($database['host'],$database['user'],$database['password'],$database['name']) or die(mysqli_error($conn));
                        $q1 = "SELECT Matricola, Nome, Cognome FROM PT";
                        $res = mysqli_query($connessione1, $q1);
                    
                        while($entry = mysqli_fetch_assoc($res)){
                            echo $entry["Nome"]." ".$entry["Cognome"]." <input type='radio' name='pt' value='".$entry["Matricola"]."'>";
                    }
                    ?>
                 </div>

                 <div id="scheda">
                    <h2> Scegli la tua tipologia di allenamento </h2>
                    <?php 
                        $connessione2 = mysqli_connect($database['host'],$database['user'],$database['password'],$database['name']) or die(mysqli_error($conn));
                        $q2 = "SELECT Numero, Tipologia, Durata, Difficoltà FROM Programma";
                        $res = mysqli_query($connessione2, $q2);
                    
                        while($entry = mysqli_fetch_assoc($res)){
                            echo $entry["Tipologia"].", ".$entry["Durata"]." mesi, difficoltà ".$entry["Difficoltà"]." <input type='radio' name='scheda' value='".$entry["Numero"]."'>";
                    }
                    ?>
                 </div>
               </div>

               <div class="submit">
                    <input type='submit' value="Invia" id="submit">
                </div>

            </form>
            <div class="signup">Hai un account? <a href="login.php">Accedi</a>
            </div>
        </section>
        </main>
    </body>
</html>