<?php 
    include 'database.php';

    header('Content-Type: application/json');

    $conn = mysqli_connect($database['host'], $database['user'], $database['password'], $database['name']);

    $query = "SELECT ID,Nome,Immagine,Descrizione FROM Corso ";
    $res = mysqli_query($conn, $query) or die(mysqli_error($conn));
    
    $postArray = array();
    while($entry = mysqli_fetch_assoc($res)) {
        $postArray[] = array('ID' => $entry["ID"], 
        'Nome' => $entry['Nome'], 
        'Immagine' => $entry['Immagine'], 
        'Descrizione' => $entry['Descrizione']);
    }
    echo json_encode($postArray);
    
    exit; ?>