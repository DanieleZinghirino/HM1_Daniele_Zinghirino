<?php 
require_once 'verifica_sessione.php';

if (!verificaSessione()){
    header("Location: login.php");
    exit;
}   

if (!empty($_POST["corso"])){
    $error=0;
    $conn = mysqli_connect($database['host'],$database['user'],$database['password'],$database['name']) or die(mysqli_error($conn));

    $cliente = $_SESSION["codice_fiscale"];
    $ID=$_POST["corso"];

    $query="DELETE FROM PARTECIPA WHERE Corso = $ID";

    $res = mysqli_query($conn, $query);
    if (!$res) {
        $error++;
        echo("<p class='errore'>");
        echo("Errore di connessione al database!");
        echo("</p>");}
    if($error==0){
        header("Location: profile.php");
        exit;}
}
?>

<html>
    <head>
    <meta charset="utf-8">
    <title>Daniele Zinghirino: Homework1</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Dela+Gothic+One&display=swap" rel="stylesheet">
    <link href="style/form.css" rel="stylesheet" type="text/css">

        <title>Iscriviti</title>
    </head>
    <body>
        <main>
        <section>
            <h1>Elimina corso</h1>
            <div id="allineamento">
            <form name='iscrizione' method='post'>
                <div>
                

                 <div id="corso">
                    <h2> Scegli il corso da eliminare </h2>
                    <?php 
                        $connessione1 = mysqli_connect($database['host'],$database['user'],$database['password'],$database['name']) or die(mysqli_error($conn));
                        $cliente = $_SESSION["codice_fiscale"];
                        $q1 = "SELECT ID,Nome FROM CORSO JOIN PARTECIPA WHERE Cliente = '$cliente' AND Corso = ID";
                        $res = mysqli_query($connessione1, $q1);
                    
                        while($entry = mysqli_fetch_assoc($res)){
                            echo $entry["Nome"]." "." <input type='radio' name='corso' value='".$entry["ID"]."'>";
                    }
                    ?>
                 </div>

                
               </div>

               <div class="submit">
                    <input type='submit' value="Cancella iscrizione dal corso" id="submit">
                </div>
                <div><a href="profile.php">Indietro</a>
            </div>

            </form>
        </section>
        </main>
    </body>
</html>