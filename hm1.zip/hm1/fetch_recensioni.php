<?php 
    require_once 'verifica_sessione.php';

    header('Content-Type: application/json');

    $conn = mysqli_connect($database['host'], $database['user'], $database['password'], $database['name']);

    $query = "SELECT ID,Testo,Nome,Cognome,Data_Recensione,Ora FROM Commento JOIN Cliente WHERE Cliente=Codice_Fiscale ";
    $res = mysqli_query($conn, $query) or die(mysqli_error($conn));
    
    $postArray = array();
    while($entry = mysqli_fetch_assoc($res)) {
        $postArray[] = array(
        'ID' => $entry["ID"], 
        'Testo' => $entry['Testo'], 
        'Nome' => $entry['Nome'], 
        'Cognome' => $entry['Cognome'], 
        'Data_Recensione' => $entry['Data_Recensione'],
        'Ora' => $entry['Ora']);
    }
    echo json_encode($postArray);
    
    exit; ?>