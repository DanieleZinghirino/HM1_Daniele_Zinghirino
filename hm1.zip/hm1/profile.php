<?php 
    require_once 'verifica_sessione.php';
    if (!$_SESSION["codice_fiscale"] = verificaSessione()) {
        header("Location: login.php");
        exit;
    }
?>

<html>
    <head>
    <meta charset="utf-8">
    <title>Daniele Zinghirino: Homework1</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Dela+Gothic+One&display=swap" rel="stylesheet">
    <link href="style/profile.css" rel="stylesheet" type="text/css">

    </head>

    <body>
       
      <section>
        <div id="top">
          
          <div> 
            <a class="button" href="home.php">Home</a> 
          </div>
         <div> <h1> PROFILO </h1> 
          </div>
          <div>         
        <a class="button" href="logout.php">Esci</a>
          
        </div>
       </div>
      
        <div id="blocco"> 
          <div> <a href="dati.php"> I tuoi dati </a> </div>
          <div> <a href="abbonamento.php"> Il tuo abbonamento </a> </div>
          <div> <a href="allenamento.php"> Il tuo piano di allenamento </a> </div>
          <div> <a href="PT.php"> Il tuo personal trainer </a> </div>
          <div> <a href="corsi_utente.php"> I tuoi corsi </a> </div>     
          <div> <a href="aggiungi_recensione.php"> Lascia una recensione </a> </div>
  
          </div>
        </section>
    </body>
</html>