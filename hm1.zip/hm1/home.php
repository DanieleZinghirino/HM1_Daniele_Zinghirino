<?php include 'verifica_sessione.php'; 
?>

<html>
<head>
    <meta charset="utf-8">
    <title>Daniele Zinghirino: Homework1</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Dela+Gothic+One&display=swap" rel="stylesheet">
    <link href="style/home.css" rel="stylesheet" type="text/css">
</head>


<body>
    <header>
        <nav>
            <div id="firma">
                BeFIT Palestre
            </div>
            <div id="links">
                <a href="sedi.php">Struttura</a>
                
                <a href="corsi.php">Corsi</a>
                <a href="orari.php">Orari</a>
                <a href="istruttori.php">Istruttori</a>
                <a href="esercizi.php">Esercizi</a>
                <a href="recensioni.php">Recensioni</a>
                <a class="button" href="login.php"> <?php if(verificaSessione()){echo "Profilo";} else{echo "Accedi";} ?></a>
            </div>
            <div id="menu">
                <div></div>
                <div></div>
                <div></div>
            </div>
        </nav>
        <h1>Scegli il tuo abbonamento e allenati con noi</h1>
    </header>
    <section>
        <div id="main">
            <h1>Ti offriamo la miglior esperienza possibile</h1>
        </div>
        <div id="box">
            <article>
                <div class="immagine">
                    <img src="immagini//article1.jpg" />
                </div>
                <div>
                    <h2 class="abbonamenti">Scegli tra i vari abbonamenti in base al tuo obiettivo!</br>
                        Molti piani di allenamento diversi e varie durate permetteranno di personalizzare il tuo abbonamento per adattarsi alle tue necessità:</br>dimagrimento, aumento di massa muscolare e tanto altro! </br>
                        <a href="iscrizione.php" class="button">Iscriviti</a>
                    </h2>
                </div>
            </article>
            <article>
                <div>
                    <h2 class="istruttori">
                        Fatti guidare dai nostri professionisti dell'allenamento!</br>
                        I nostri preparatissimi personal trainer ti aspettano per accompagnarti nel tuo nuovo percorso e saranno a disposizione per ogni dritta e per tutte le modifiche necessarie al tuo piano di allenamento per ottimizzare il tuo lavoro! </br>
                        <a class="button" href="istruttori.php">Istruttori</a>
                    </h2>
                </div>
                <div class="immagine">
                    <img src="immagini/article2.jpg" />
                </div>
            </article>
            <article>
                <div class="immagine">
                    <img src="immagini/article3.jpg" />
                </div>
                <div>
                    <h2 class="attrezzi">
                        Mettiamo a tua disposizione tutti gli attrezzi più moderni per tenerti sempre in forma!</br>
                        La palestra è sempre aggiornata per offrire a tutti i suoi clienti le migliori attrezzature possibili in grado di ottimizzare il lavoro degli atleti e minimizzare i rischi! </br>
                        <a class="button" href="sedi.php">Struttura</a>
                    </h2>
                </div>
            </article>
        </div>
        <h1>Statistiche</h1>
        <h2>Percentuale rinnovi: <?php
            $url = 'http://localhost/hm1/fetch_percentuale_rinnovi.php';
            $curl = curl_init($url);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
            $data = curl_exec($curl);
            $json = json_decode($data, true);
            echo json_encode($json);
            curl_close($curl); ?></h2>
        <?php 


        ?>

    </section>
    <footer>
        <p> Daniele Zinghirino O46002178 </p>
    </footer>
</body>

</html>
