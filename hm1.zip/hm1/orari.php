<html>
    <head>
    <meta charset="utf-8">
    <title>Daniele Zinghirino: Homework1</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Dela+Gothic+One&display=swap" rel="stylesheet">
    <link href="style/profile.css" rel="stylesheet" type="text/css">
    <script src="script/json_orari.js" defer></script>
    </head>

    <body>
      <h1> Orario </h1>
      <div class="dato">
          
        <p> Lunedì dalle 08:00 alle 22:00 </p>
        <p> Martedì dalle 08:00 alle 22:00 </p>
        <p> Mercoledì dalle 08:00 alle 22:00 </p>
        <p> Giovedì dalle 08:00 alle 22:00 </p>
        <p> Venerdì dalle 08:00 alle 22:00 </p>
        <p> Sabato dalle 10:00 alle 16:00 </p>
        <p> I giorni festivi la palestra resterà chiusa</p>
        </br>
        <div id="verifica">
            <div class="orario">
                <h2>Verifica l'orario odierno della nostra palestra</h2>
                <div> <button> Verifica </button> </div>
            </div>
        </div>
      </div>
        <a class="button" href="home.php"> Indietro </a>
    </body>
</html>