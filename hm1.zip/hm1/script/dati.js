function fetch_dati_json(json) {
    const elenco = document.getElementById("dati");
    elenco.innerHTML = '';

    for (let dato in json) {
        console.log(json[0]);
    }

    let x = document.createElement("span");
    x.textContent = "Nome = " + json[0].Nome;
    x.classList.add("dato");
    elenco.appendChild(x);
    x = document.createElement("span");
    x.textContent = "Cognome = " + json[0].Cognome;
    x.classList.add("dato");
    elenco.appendChild(x);
    x = document.createElement("span");
    x.textContent = "Codice fiscale = " + json[0].Codice_Fiscale;
    x.classList.add("dato");
    elenco.appendChild(x);
    x = document.createElement("span");
    x.textContent = "Data di nascita = " + json[0].Data_Nascita;
    x.classList.add("dato");
    elenco.appendChild(x);
    x = document.createElement("span");
    x.textContent = "Età = " + json[0].Eta + " anni";
    x.classList.add("dato");
    elenco.appendChild(x);

}

function fetchResponse(response) {
    return response.json();
}

function fetch_dati_anagrafici() {

    fetch("fetch_dati.php").then(fetchResponse).then(fetch_dati_json);
}

fetch_dati_anagrafici();