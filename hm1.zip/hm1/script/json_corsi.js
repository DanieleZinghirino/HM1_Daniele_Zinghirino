function fetch_corsi_json(json) {
    const elenco = document.getElementById("dati");
    elenco.innerHTML = '';
    if (json.length) {
        for (var i = 0; i < json.length; i++) {
            var elemento = json[i];
            console.log(elemento);

            let x;

            x = document.createElement("span");
            x.textContent = "Corso #" + elemento.ID;
            x.classList.add("titolo");
            elenco.appendChild(x);
            x = document.createElement("span");
            x.textContent = "Nome = " + elemento.Nome;
            x.classList.add("dato");
            elenco.appendChild(x);
            x = document.createElement("span");
            x.textContent = "Giorno = " + elemento.Giorno;
            x.classList.add("dato");
            elenco.appendChild(x);
            x = document.createElement("span");
            x.textContent = "Orario = " + elemento.Ora;
            x.classList.add("dato");
            elenco.appendChild(x);


        }
        let bottone = document.createElement("a");
        bottone.textContent = "Elimina corso";
        bottone.classList.add("button");
        bottone.href = "elimina_corso.php";

        elenco.appendChild(bottone);
    } else {
        let x;

        x = document.createElement("span");
        x.textContent = "Non sei iscritto a nessun corso!";
        x.classList.add("dato");
        elenco.appendChild(x);


    }
    let bottone = document.createElement("a");
    bottone.textContent = "Iscriviti ad un corso";
    bottone.classList.add("button");
    bottone.href = "iscrizione_corso.php";

    elenco.appendChild(bottone);
}

function fetchResponse(response) {
    return response.json();
}

function fetch_abbonamento() {

    fetch("fetch_corsi_utente.php").then(fetchResponse).then(fetch_corsi_json);
}

fetch_abbonamento();