function fetch_sedi_json(json) {
    const elenco = document.getElementById("dati");
    elenco.innerHTML = '';
    for (var i = 0; i < json.length; i++) {
        var elemento = json[i];
        console.log(elemento);

        let x;
        x = document.createElement("span");
        x.textContent = "Sede #" + elemento.ID;
        x.classList.add("dato");
        elenco.appendChild(x);

        x = document.createElement("span");
        x.textContent = "Città = " + elemento.Città;
        x.classList.add("dato");
        elenco.appendChild(x);

        x = document.createElement("span");
        x.textContent = "Indirizzo = " + elemento.Indirizzo;
        x.classList.add("dato");
        elenco.appendChild(x);

        x = document.createElement("span");
        x.textContent = "Direttore = " + elemento.Nome + " " + elemento.Cognome;
        x.classList.add("dato");
        elenco.appendChild(x);

        x = document.createElement("span");
        x.textContent = " ";
        x.classList.add("dato");
        elenco.appendChild(x);
    }

}

function fetchResponse(response) {
    return response.json();
}

function fetch_sedi() {

    fetch("fetch_sedi.php").then(fetchResponse).then(fetch_sedi_json);
}

fetch_sedi();