function fetch_istruttore_json(json) {
    const elenco = document.getElementById("dati");
    elenco.innerHTML = '';
    for (var i = 0; i < json.length; i++) {
        var elemento = json[i];
        console.log(elemento);

        let x;

        x = document.createElement("span");
        x.textContent = "Nome = " + elemento.Nome;
        x.classList.add("dato");
        elenco.appendChild(x);

        x = document.createElement("span");
        x.textContent = "Cognome = " + elemento.Cognome;
        x.classList.add("dato");
        elenco.appendChild(x);

        x = document.createElement("span");
        x.textContent = "Data di nascita = " + elemento.Data_Nascita;
        x.classList.add("dato");
        elenco.appendChild(x);

        x = document.createElement("span");
        x.textContent = "Numero di matricola = " + elemento.Matricola;
        x.classList.add("dato");

        spazio = document.createElement("br");

        elenco.appendChild(x);
        elenco.appendChild(spazio);
    }

}

function fetchResponse(response) {
    return response.json();
}

function fetch_istruttore() {

    fetch("fetch_istruttori.php").then(fetchResponse).then(fetch_istruttore_json);
}

fetch_istruttore();