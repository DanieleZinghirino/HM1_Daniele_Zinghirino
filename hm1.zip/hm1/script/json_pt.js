function fetch_pt_json(json) {
    const elenco = document.getElementById("dati");
    for (var i = 0; i < json.length; i++) {
        var elemento = json[i];
        console.log(elemento);

        elenco.innerHTML = '';
        let x;

        x = document.createElement("span");
        x.textContent = "Nome = " + elemento.Nome_Istruttore;
        x.classList.add("dato");
        elenco.appendChild(x);

        x = document.createElement("span");
        x.textContent = "Cognome = " + elemento.Cognome_Istruttore;
        x.classList.add("dato");
        elenco.appendChild(x);

        x = document.createElement("span");
        x.textContent = "Data di nascita = " + elemento.Data_Istruttore;
        x.classList.add("dato");
        elenco.appendChild(x);

        x = document.createElement("span");
        x.textContent = "Numero di matricola = " + elemento.Matricola_Istruttore;
        x.classList.add("dato");
        elenco.appendChild(x);

        let bottone = document.createElement("a");
        bottone.textContent = "Cambia personal trainer";
        bottone.classList.add("button");
        bottone.href = "cambio_pt.php";

        elenco.appendChild(bottone);
    }

}

function fetchResponse(response) {
    return response.json();
}

function fetch_pt() {

    fetch("fetch_dati.php").then(fetchResponse).then(fetch_pt_json);
}

fetch_pt();