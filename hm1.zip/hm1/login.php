<?php
 include 'verifica_sessione.php';
 if (verificaSessione()) {
     header('Location: profile.php');
     exit;
 }

 if (!empty($_POST["codice_fiscale"]) && !empty($_POST["password"]) )
 {

    $conn = mysqli_connect($database['host'],$database['user'],$database['password'],$database['name']) or die(mysqli_error($conn));

    $codice_fiscale = mysqli_real_escape_string($conn, $_POST['codice_fiscale']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    $query = "SELECT Codice_Fiscale, Pass FROM Cliente WHERE Codice_Fiscale = '$codice_fiscale' ";

    $res = mysqli_query($conn, $query) or die(mysqli_error($conn));

    if (mysqli_num_rows($res) > 0) {
        $entry = mysqli_fetch_assoc($res);
       
        print_r($entry);
        if($entry['Pass'] == $_POST['password']){
        $_SESSION["codice_fiscale"] = $_POST['codice_fiscale'];
        //echo($_SESSION["codice_fiscale"]);
        header("Location: profile.php");

        mysqli_free_result($res);
        mysqli_close($conn);}
        else {echo("<p class='errore'>");
              echo("Password errata!");
              echo("</p>");}

        /*if (password_verify($_POST['password'], $entry['pw'])) {
            $_SESSION["codice_fiscale"] = $entry['codice_fiscale'];
            $_SESSION["id"] = $entry['id'];
            header("Location: home.php");
            mysqli_free_result($res);
            mysqli_close($conn);
            exit;
        }*/
    }
    else {echo("<p class='errore'>");
        echo("Non sei iscritto!");
        echo("</p>");}

    /*if($_POST["codice_fiscale"] == "cf" && $_POST["password"]=="password"){
        $_SESSION["codice_fiscale"] = $_POST["codice_fiscale"];
        header("location:profile.php");
    }
    else{
        echo("CREDENZIALI ERRATE");
    }*/
 }
 //else echo("Inserisci le credenziali!");
?>



<html>
    <head>
    <meta charset="utf-8">
    <title>Daniele Zinghirino: Homework1</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Dela+Gothic+One&display=swap" rel="stylesheet">
    <link href="style/form.css" rel="stylesheet" type="text/css">
    <script src="script/verifica_credenziali.js" defer></script>
    </head>

    <body>
        <h1> LOGIN </h1>
      <div id="allineamento">
        
        <form name='credenziali' method ='post'>   
          
            <div class='codice_fiscale'>
                <div><label for='codice_fiscale'>Codice fiscale</label ></div>
                <div><input type='text' name='codice_fiscale' <?php if(isset($_POST["codice_fiscale"])){echo "value=".$_POST["codice_fiscale"];} ?>></div>
            </div>
            <div class='password'>
                <div><label for='password'>Password</label></div>
                <div><input type='password' name='password' <?php if(isset($_POST["password"])){echo "value=".$_POST["password"];} ?>></div>
            </div>
            <div id="invio">
                 <input type='submit' value="Accedi">
            </div>
        </form>
        <div class="signup">Non hai un account? <a href="iscrizione.php">Iscriviti</a></div>
        </div>
        </body>
</html>