create database homework1;
use homework1;

CREATE TABLE PALESTRA(
         ID integer primary key,
         Nome varchar(20));    
CREATE TABLE DIRETTORE(
         Matricola integer primary key,
         Nome varchar(20),
         Cognome varchar(20),
         Data_Nascita date);
CREATE TABLE SEDE(
         ID integer,
         Palestra integer,
         Città varchar(20),
         Indirizzo varchar(20),
         Direttore integer,
         primary key(ID,Palestra),
         index idx_palestra(Palestra), index idx_direttore(Direttore),
         foreign key(Palestra) references PALESTRA(ID), foreign key(Direttore) references DIRETTORE(Matricola));
CREATE TABLE CLIENTE(
	Codice_Fiscale varchar(20) primary key,
	Nome varchar(20),
	Cognome varchar(20),
	Data_Nascita date, 
	Età integer,
    Pass varchar(255));
CREATE TABLE UTENTE(
	Cliente varchar(20) primary key,
    Pass varchar(20),
    index id_utente(Cliente),
    foreign key(Cliente) references CLIENTE(Codice_Fiscale));
CREATE TABLE AGONISTA(
	Persona varchar(20) primary key,    
	Competizione varchar(20),    
	index idx_agonista(Persona),   
	foreign key(Persona) references CLIENTE(Codice_Fiscale));
 CREATE TABLE EVENTO(	
	Codice integer primary key,    
	Livello integer);
CREATE TABLE GAREGGIA(	
	Atleta varchar(20),    
	Evento integer,    
	primary key(Atleta,Evento),   
	index idx_atleta(Atleta),    
	foreign key(Atleta) references AGONISTA(Persona));
CREATE TABLE ABBONAMENTO(	
	Codice integer,    
	Cliente varchar(20),   
	Palestra integer,    
	Prezzo float,    
	Durata integer,    
	Data_Iscrizione date,   
	Data_Scadenza date,    
	primary key(Codice,Cliente,Palestra),    
	index idx_cliente2(Cliente), index idx_palestra3(Palestra),    
	foreign key(Cliente) references CLIENTE(Codice_Fiscale),foreign key(Palestra) references PALESTRA(ID));
CREATE TABLE PROGRAMMA(
	Numero integer primary key,    
	Durata integer,   
	Difficoltà integer,    
	Tipologia varchar(200));
CREATE TABLE PT(	
	Palestra integer,   
	Matricola integer,    
	Nome varchar(20),    
	Cognome varchar(20),    
	Data_Nascita date,	
	primary key(Palestra, Matricola),   
	index idx_palestra(Palestra),    
	foreign key(Palestra) references PALESTRA(ID));
CREATE TABLE ALLENAMENTO (    
	Palestra integer,	
	Istruttore integer,    
	Scheda integer,    
	Cliente varchar(20),    
	primary key(Palestra, Istruttore, Scheda, Cliente),	
	index ix_palestra(Palestra),index ix_istruttore(Istruttore),index ix_scheda(Scheda),index ix_cliente(Cliente),   
	foreign key (Palestra, Istruttore) references PT(Palestra, Matricola),foreign key (Scheda) references PROGRAMMA(Numero),    
	foreign key (Cliente) references CLIENTE(Codice_Fiscale));
CREATE TABLE CORSO(	
	ID integer primary key,    
	Nome varchar(20),     
	Ora varchar(5),     
	Giorno varchar(20),
    Immagine varchar(255),
    Descrizione varchar(2555));
CREATE TABLE PARTECIPA(	
	Cliente varchar(20),     
	Corso integer,    
	primary key(Cliente, Corso),    
	index idx_cliente4(Cliente),index idx_corso(Corso),    
	foreign key(Cliente) references CLIENTE(Codice_Fiscale), foreign key(Corso) references CORSO(ID));
CREATE TABLE ATTREZZO(
	ID integer primary key,    
              Nome varchar(20),     
	Tipo varchar(20)) ;
CREATE TABLE DISPONE(	
	Palestra integer,    
	Attrezzo integer,    
	primary key(Palestra, Attrezzo),    
	index idx_palestra6(Palestra),index idx_attrezzo(Attrezzo),    
	foreign key(Palestra) references PALESTRA(ID),foreign key(Attrezzo) references ATTREZZO(ID));

CREATE TABLE COMMENTO(
	ID integer primary key,
    Testo varchar(1000),
    Cliente varchar(20),
    Data_Recensione date,
    Ora varchar(5),
    index id_xcliente(Cliente),
    foreign key(Cliente) references CLIENTE(Codice_Fiscale));

INSERT INTO PALESTRA(ID, Nome)
VALUES (1,"BeFit");

INSERT INTO PT(Palestra, Matricola, Nome, Cognome, Data_Nascita)
VALUES (1,1,'Giovanni','Longo','1980-07-21'),
(1,2,'Benedetto','Privitera','1992-12-02'),
(1,3,'Salvatore','Spampinato','1976-03-14'),
(1,4,'Maria','Verde','1986-05-05'),
(1,5,'Lucrezia','Scalia','1981-10-20');

INSERT INTO PROGRAMMA(Numero, Durata, Difficoltà, Tipologia)
VALUES(1,1,1,'Definizione'),
(2,2,2,'Aumento massa muscolare'),
(3,3,3,'Forza'),
(4,2,4,'Resistenza'),
(5,3,2,'Dimagrimento');

INSERT INTO CORSO(ID,Nome,Ora,Giorno,Immagine,Descrizione)
VALUES(1,'PUGILATO',19.00,'Lunedì','immagini/Pugilato.jpg',"L’allenamento comprende un veloce riscaldamento  a cui seguono esercizi mirati alo sviluppo di coordinazione, forza, velocità e resistenza. Si passa poi alle tecniche e tattiche specifiche, che comprendono la tecnica pugilistica, la scelta di tempo e delle distanze. Il contatto tra gli atleti avviene sempre  in sicurezza."),
(2,'WORKOUT',17.00,'Martedì','immagini/Workout.jpg',"Il Total Body workout è un tipo di allenamento in cui si praticano esercizi che coinvolgono tutto il corpo. L’allenamento è composto da un mix di esercizi: statici, dinamici, di equilibrio funzionale, forza e definizione muscolare. Nel workout si usano grandi e piccoli attrezzi fitness, e macchine cardio fitness."),
(3,'AEROBICA',18.30,'Mercoledì','immagini/Aerobica.jpg',"Si tratta di ginnastica a corpo libero con elementi coreografici a ritmo di musica, il cui obiettivo è l’allenamento delle funzioni cardiovascolari e respiratorie, la tonificazione e il consumo calorico. La diversità delle tecniche usate, così come l’impiego di attrezzi (step, cavigliere, manubri, ecc.) permette ai partecipanti di diversificare l'allenamento cardiovascolare rendendolo vario e stimolante allo stesso tempo."),
(4,'KARATE',17.45,'Giovedì','immagini/Karate.jpg',"Al pari di altre arti marziali, il karate, è uno sport completo che coinvolge tutti i muscoli e le articolazioni del corpo. Per questa ragione è uno sport consigliato allo stesso modo per bambini, adolescenti e adulti, ai quali è offerta la possibilità di elevarsi, all'interno di questa disciplina, attraverso sette gradi culminanti nella cintura nera."),
(5,'YOGA',19.30,'Venerdì','immagini/Yoga.jpg',"Lo yoga ha diversi benefici: il corpo viene tonificato, reso flessibile e forte, ne giovano articolazioni, muscoli, organi interni, migliora l’elasticità della colonna vertebrale; la mente che diventa più calma, aperta e ricettiva, siamo più rilassati, migliora la qualità del sonno, del riposo e la concentrazione; il respiro viene migliorato perchè si impara a respirare correttamente e a fondo, usando tutta la propria capacità respiratoria, questo porta ad una migliore ossigenazione del sangue, con conseguenze positive su tutto il corpo e sulla mente"),
(6,'SPINNING',14.30,'Sabato','immagini/Spinning.jpg',"Una pedalata di gruppo su una cyclette particolare (detta bike da indoor) e sotto la guida attenta di un istruttore, che usa una base musicale per impostare il lavoro");

INSERT INTO CLIENTE(Codice_Fiscale, Nome, Cognome, Data_Nascita, Età, Pass)
VALUES ('PROVA','Giuseppe','Verdi','2000-01-01',21,'provaprova'),
('ZNGDNL99H06C531F','Daniele','Zinghirino','1999-06-06',21,'aaaaaaaa');

INSERT INTO ABBONAMENTO(Codice, Cliente, Palestra, Prezzo, Durata, Data_Iscrizione,Data_Scadenza)
VALUES (99,'ZNGDNL99H06C531F',1,300,12,'2020-01-04','2021-01-04'),
(100,'ZNGDNL99H06C531F',1,300,12,'2021-02-04','2022-02-04'),
(12,'PROVA',1,300,12,'2021-01-01','2022-01-01');

INSERT INTO ALLENAMENTO(Palestra,Istruttore,Scheda,Cliente)
VALUES(1,2,3,'ZNGDNL99H06C531F'),
(1,3,2,'PROVA');

INSERT INTO DIRETTORE(Matricola,Nome,Cognome,Data_Nascita)
VALUES(1,'Carmela','Biondi','1976-01-24'),
(2,'Giovanni','Moro','1983-10-30'),
(3,'Andrea','Bianchi','1972-04-12'),
(4,'Concetta','Rossi','1980-11-04'),
(5,'Orazio','Verdi','1966-06-15');

INSERT INTO SEDE(ID,Palestra,Città,Indirizzo,Direttore)
VALUES(1,1,'Catania','Corso Italia',3),
(2,1,'Catania','Via Etnea',2),
(3,1,'Palermo','Via Roma',1),
(4,1,'Roma','Via del Corso',4),
(5,1,'Milano','Via Manzoni',5);

INSERT INTO COMMENTO(ID,Testo,Cliente,Data_Recensione,Ora)
VALUES (1,'Ottima struttura!','ZNGDNL99H06C531F','2021-05-05','18.30');

CREATE VIEW RINNOVO AS
SELECT A1.CODICE AS Abbonamento, A2.CLIENTE AS Cliente
FROM ABBONAMENTO A1 JOIN ABBONAMENTO A2 ON A1.Cliente = A2.Cliente 
WHERE A1.CODICE <> A2.CODICE
GROUP BY A1.CLIENTE;


