<?php 
    include 'database.php';
    header('Content-Type: application/json');

    $conn = mysqli_connect($database['host'], $database['user'], $database['password'], $database['name']);

    $query = "SELECT ID,Città, Indirizzo, Nome, Cognome, Matricola FROM DIRETTORE JOIN SEDE  WHERE MATRICOLA = DIRETTORE";
    $res = mysqli_query($conn, $query) or die(mysqli_error($conn));
    
    $postArray = array();
    while($entry = mysqli_fetch_assoc($res)) {
        $postArray[] = array('ID'=>$entry["ID"],
        'Città' => $entry["Città"], 
        'Indirizzo' => $entry['Indirizzo'], 
        'Nome' => $entry['Nome'], 
        'Cognome' => $entry['Cognome'], 
        'Matricola' => $entry['Matricola']);
    }
    echo json_encode($postArray);
    
    exit; ?>