<?php 
$app_key = '463c35ffb70e4e5fb4ac42c5467167f7';
$anno = date("Y");
$mese = date('m');
$giorno = date('d');
$url='https://holidays.abstractapi.com/v1/?api_key='.$app_key.'&country=It&year='.$anno.'&month='.$mese.'&day='.$giorno;

$curl = curl_init($url);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
$data = curl_exec($curl);
$json = json_decode($data, true);
curl_close($curl);

/*$newJson = array();

for ($i = 0; $i < count($json); $i++) {
    $newJson[] = array('Nome' => $json['data'][$i]['name'], 
                       'Data' => $json['data'][$i]['date']);
}*/

if ($json) {
    $newJson = 1;
}
else $newJson = 0;
echo json_encode($newJson); //RITORNA 1 SE E' FESTIVO, ALTRIMENTI RITORNA 0
?>