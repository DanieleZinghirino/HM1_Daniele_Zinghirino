<?php 
require_once 'verifica_sessione.php'; 

if (!empty($_POST["pt"])){
    $error=0;
    $conn = mysqli_connect($database['host'],$database['user'],$database['password'],$database['name']) or die(mysqli_error($conn));

    $cliente = $_SESSION["codice_fiscale"];
    $PT=$_POST["pt"];

    $q="SELECT Scheda FROM ALLENAMENTO WHERE Cliente = '$cliente'";
    $res = mysqli_query($conn, $q);
    
    $entry = mysqli_fetch_assoc($res);
    $scheda = $entry["Scheda"];

    $query1="DELETE FROM ALLENAMENTO WHERE Cliente = '$cliente' ";
    $ris = mysqli_query($conn, $query1);

    $query="INSERT INTO ALLENAMENTO(Palestra,Istruttore,Scheda,Cliente)
    VALUES (1,$PT,$scheda,'$cliente')";

    $res = mysqli_query($conn, $query);
    if (!$res) {
        $error++;
        echo("<p class='errore'>");
        echo("Errore di connessione al database!");
        echo("</p>");}
    if($error==0){
        header("Location: profile.php");
        exit;}
}
?>

<html>
    <head>
    <meta charset="utf-8">
    <title>Daniele Zinghirino: Homework1</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Dela+Gothic+One&display=swap" rel="stylesheet">
    <link href="style/form.css" rel="stylesheet" type="text/css">

        <title>Iscriviti</title>
    </head>
    <body>
        <main>
        <section>
            <h1>Scegli il tuo personal trainer</h1>
            <div id="allineamento">
            <form name='iscrizione' method='post'>
                <div>
                

                 <div id="pt">
                    <?php 
                        $connessione1 = mysqli_connect($database['host'],$database['user'],$database['password'],$database['name']) or die(mysqli_error($conn));
                        $cliente = $_SESSION["codice_fiscale"];
                        $q1 = "SELECT Matricola, Nome, Cognome FROM PT WHERE Matricola NOT IN 
                        (SELECT ISTRUTTORE FROM ALLENAMENTO WHERE Cliente = '$cliente')";
                        $res = mysqli_query($connessione1, $q1);
                    
                        while($entry = mysqli_fetch_assoc($res)){
                            echo $entry["Nome"]." ". $entry["Cognome"]." <input type='radio' name='pt' value='".$entry["Matricola"]."'>";
                    }
                    ?>
                 </div>

                
               </div>

               <div class="submit">
                    <input type='submit' value="Conferma" id="submit">
                </div>

                <div><a href="profile.php">Indietro</a>
            </div>

            </form>
        </section>
        </main>
    </body>
</html>