<?php 
    require_once 'verifica_sessione.php';
    if (!$_SESSION["codice_fiscale"]  = verificaSessione()) exit;

    header('Content-Type: application/json');

    $conn = mysqli_connect($database['host'], $database['user'], $database['password'], $database['name']);

    $cf=$_SESSION["codice_fiscale"];
    $query = "SELECT ID,Nome,Immagine,Descrizione,Ora,Giorno FROM Corso JOIN Partecipa Where Cliente = '$cf' And Corso = ID ";
    $res = mysqli_query($conn, $query) or die(mysqli_error($conn));
    
    $postArray = array();
    while($entry = mysqli_fetch_assoc($res)) {
        $postArray[] = array(
        'ID' => $entry["ID"], 
        'Nome' => $entry['Nome'], 
        'Immagine' => $entry['Immagine'], 
        'Descrizione' => $entry['Descrizione'],
        'Giorno' => $entry['Giorno'],
        'Ora' => $entry['Ora']);
    }
    echo json_encode($postArray);
    
    exit; ?>