<?php 
require_once 'verifica_sessione.php';

if (!verificaSessione()){
    header("Location: login.php");
    exit;
}   

if (!empty($_POST["recensione"])){
    $error=0;
    $conn = mysqli_connect($database['host'],$database['user'],$database['password'],$database['name']) or die(mysqli_error($conn));

    $testo = $_POST["recensione"];
    $cliente = $_SESSION["codice_fiscale"];
    $data=date ("Y/m/d");
    $ora = date("H:i:s");  
   
    do{
        $ID=rand(1,100000000);
        $query = "SELECT ID FROM COMMENTO WHERE ID = $ID ";
        $res = mysqli_query($conn, $query);
    }
    while(mysqli_num_rows($res) > 0);

    $query="INSERT INTO COMMENTO(ID,Testo,Cliente,Data_Recensione,Ora)
    VALUES ($ID,'$testo','$cliente','$data','$ora')";


    $res = mysqli_query($conn, $query);
    if (!$res) {
        $error++;
        echo("<p class='errore'>");
        echo("Errore di connessione al database!");
        echo("</p>");}
    if($error==0){
         header("Location: recensioni.php");
        exit;}
}
?>

<html>
    <head>
    <meta charset="utf-8">
    <title>Daniele Zinghirino: Homework1</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Dela+Gothic+One&display=swap" rel="stylesheet">
    <link href="style/form.css" rel="stylesheet" type="text/css">
    <script src="script/form.js" defer></script>

        <title>Iscriviti</title>
    </head>
    <body>
        <main>
        <section>
            <h1>Scegli il tuo abbonamento</h1>
            <div id="allineamento">
            <form name='iscrizione' method='post'>
                <div>
                
                  <div id="abbonamento">
                        <h2> Inserisci il tuo commento </h2>
                        <input type="text" name="recensione"> 
                 </div>

               </div>

               <div class="submit">
                    <input type='submit' value="Invia" id="submit">
                </div>

</form>
            <div><a href="recensioni.php">Indietro</a>
            </div>
        </section>
        </main>
    </body>
</html>