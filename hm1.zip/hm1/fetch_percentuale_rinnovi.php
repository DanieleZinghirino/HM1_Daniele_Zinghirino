<?php 
    include 'database.php';
    header('Content-Type: application/json');

    $conn = mysqli_connect($database['host'], $database['user'], $database['password'], $database['name']);

    $query = "SELECT  COUNT(R.Abbonamento) / COUNT(ALL C.Codice_Fiscale) * 100 AS PERCENTUALE_RINNOVI
    FROM RINNOVO R RIGHT JOIN CLIENTE C ON R.Cliente = C.Codice_Fiscale ;";
    $res = mysqli_query($conn, $query) or die(mysqli_error($conn));

    if($entry = mysqli_fetch_assoc($res)){
        $post =  $entry['PERCENTUALE_RINNOVI'];
    }

    echo json_encode($post);
    
    exit; ?>