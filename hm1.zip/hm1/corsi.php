<?php 
include 'database.php';

?>

<html>
<head>
    <meta charset="utf-8">
    <title>Daniele Zinghirino: Homework1</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Dela+Gothic+One&display=swap" rel="stylesheet">
    <link href="style/corsi.css" rel="stylesheet" type="text/css">
    <script src="script/jcorso.js" defer></script>
</head>

    <body>
        
            <h1> Scopri i nostri corsi e segna i tuoi preferiti</h1>
        
        
        <div id="allineamento"> <input type="text" id="ricerca"> </div>

        <div id="griglia">


        <?php
        $connessione1 = mysqli_connect($database['host'],$database['user'],$database['password'],$database['name']) or die(mysqli_error($conn));
        $q1 = "SELECT ID,Nome,Immagine,Descrizione FROM Corso ";
        $res = mysqli_query($connessione1, $q1); 
        while($entry = mysqli_fetch_assoc($res)){
            print '<div class ="corso" data-nome="'.$entry["Nome"].'">';
            print '<div class ="stella"> <img src="immagini/stella_vuota.png" /> </div>';
            print '<div> <h2> '.$entry["Nome"].' </h2> </div>';
            print '<img src="'.$entry["Immagine"].'" />';
            print '<p class="descrizione button">Clicca per maggiori informazioni</p> </div>';
    }
     ?>
        </div>

        <div id="textP" class="hidden">
            <h1> I tuoi corsi preferiti: </h1>
        </div>
        <div id="preferiti">

        </div>
        </div>
    <a id="bottone" href="home.php"> Indietro </a>
</body>
    </body>
</html>
