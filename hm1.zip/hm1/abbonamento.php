<?php 
    require_once 'verifica_sessione.php';
    if (!$_SESSION["codice_fiscale"] = verificaSessione()) {
        header("Location: login.php");
        exit;
    }

?>

<html>
<meta charset="utf-8">
    <title>Daniele Zinghirino: Homework1</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Dela+Gothic+One&display=swap" rel="stylesheet">
    <link href="style/profile.css" rel="stylesheet" type="text/css">
    <script src="script/json_dati_abbonamento.js" defer></script>
<head>
</head>

<body>
    <h1>Il tuo abbonamento</h1>
  <div id="dati">
   
    
  </div>
    <a class="button" href="profile.php"> Indietro </a>
</body>
    
</html>