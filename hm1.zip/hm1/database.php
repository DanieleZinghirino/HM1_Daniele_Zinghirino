<?php
    $database = [
        'host'     => '127.0.0.1',
        'name'     => 'homework1',
        'user'     => 'root',
        'password' => ''
    ];
?>
