<?php
    function ControlloData($data){
	if(!ereg("^[0-9]{2}/[0-9]{2}/[0-9]{4}$", $data)){
		return false;
	}else{
		$arrayData = explode("/", $data);
		$Giorno = $arrayData[0];
		$Mese = $arrayData[1];
		$Anno = $arrayData[2];
		if(!checkdate($Mese, $Giorno, $Anno)){
			return false;
		}else{
			return true;
		}
	}
}
?>