<?php 
    require_once 'verifica_sessione.php';
    if (!$_SESSION["codice_fiscale"]  = verificaSessione()) exit;

    header('Content-Type: application/json');

    $conn = mysqli_connect($database['host'], $database['user'], $database['password'], $database['name']);

    //$userid = mysqli_real_escape_string($conn, $_SESSION["codice_fiscale"]);
    $cf=$_SESSION["codice_fiscale"];
    $query = "SELECT Codice_Fiscale, c.Nome as Nome, c.Cognome as Cognome , c.Data_Nascita as Data_Nascita, Età, Codice, Prezzo, a.Durata as Durata_Abbonamento, 
    Data_Iscrizione, Data_Scadenza, p.Durata as Durata_Scheda, Difficoltà, Tipologia, PT.Matricola as Matricola_Istruttore, PT.Nome as Nome_Istruttore, 
    PT.Cognome as Cognome_Istruttore, PT.Data_Nascita as Data_Istruttore
    FROM CLIENTE as c JOIN ABBONAMENTO as a JOIN ALLENAMENTO as al JOIN PROGRAMMA p JOIN PT
    WHERE c.codice_fiscale=a.cliente AND c.codice_fiscale=al.cliente AND c.codice_fiscale = '$cf' AND p.Numero = al.Scheda AND PT.Matricola = al.Istruttore; ";
    $res = mysqli_query($conn, $query) or die(mysqli_error($conn));
    
    $postArray = array();
    while($entry = mysqli_fetch_assoc($res)) {
        $postArray[] = array('Nome' => $entry['Nome'], 'Cognome' => $entry['Cognome'], 'Codice_Fiscale' => $entry['Codice_Fiscale'],
                            'Data_Nascita' => $entry['Data_Nascita'], 'Eta' => $entry['Età'],
                             'Codice' => $entry['Codice'],'Prezzo' => $entry['Prezzo'],'Durata_Abbonamento' => $entry['Durata_Abbonamento'],
                             'Data_Iscrizione' => $entry['Data_Iscrizione'],'Data_Scadenza' => $entry['Data_Scadenza'], 'Durata_Scheda' => $entry['Durata_Scheda'], 
                             'Difficoltà' => $entry["Difficoltà"], 'Tipologia' => $entry['Tipologia'],
                              'Nome_Istruttore' => $entry['Nome_Istruttore'],'Cognome_Istruttore' => $entry['Cognome_Istruttore'],'Data_Istruttore' => $entry["Data_Istruttore"],
                               'Matricola_Istruttore' => $entry["Matricola_Istruttore"]);
    }
    echo json_encode($postArray);
    
    exit; ?>