<?php
  
require_once 'verifica_sessione.php';

    if (verificaSessione()){
        header("Location: profile.php");
        exit;
    }   

    
   
if (!empty($_POST["nome"]) && !empty($_POST["cognome"]) && !empty($_POST["codice_fiscale"]) && !empty($_POST["giorno_nascita"]) && 
    !empty($_POST["mese_nascita"]) && !empty($_POST["anno_nascita"]) && !empty($_POST["password"]) && !empty($_POST["confirm_password"])){
        $error = 0;
        $conn = mysqli_connect($database['host'],$database['user'],$database['password'],$database['name']) or die(mysqli_error($conn));
   
        $nome = mysqli_real_escape_string($conn, $_POST['nome']);
        $cognome = mysqli_real_escape_string($conn, $_POST['cognome']);
        $codice_fiscale = mysqli_escape_string($conn, $_POST['codice_fiscale']);
        $giorno_nascita = mysqli_escape_string($conn, $_POST['giorno_nascita']);
        $mese_nascita = mysqli_escape_string($conn, $_POST['mese_nascita']);
        $anno_nascita = mysqli_escape_string($conn, $_POST['anno_nascita']);
        $password = mysqli_real_escape_string($conn, $_POST['password']);
        $data = "$anno_nascita-$mese_nascita-$giorno_nascita";
        $data_nascita = new DateTime("$giorno_nascita.$mese_nascita.$anno_nascita");
        $data_oggi = new DateTime('00:00:00');
        $diff = $data_oggi->diff($data_nascita);
        $eta = ($diff->y);

        $query = "SELECT Codice_Fiscale FROM Cliente WHERE Codice_Fiscale = '$codice_fiscale' ";

        $res = mysqli_query($conn, $query);

        
        if (mysqli_num_rows($res) > 0) {
                echo("<p class='errore'>");
                echo("Utente già registrato!");
                echo("</p>");
            $error = $error + 1;
        }

        if (strcmp($_POST["password"], $_POST["confirm_password"]) != 0) {
            $error++;
                if($error==1){
                echo("<p class='errore'>");
                echo("Le password non coincidono!");
                echo("</p>");}}
        
         if(strlen($_POST['password'])<8){
             $error++;
             if($error==1){
                 echo("<p class='errore'>");
                 echo("Password troppo breve: inserisci almeno 8 caratteri!");
                 echo("</p>");}
                }

        

        if (checkdate($mese_nascita,$giorno_nascita,$anno_nascita)==FALSE){
            $error++; 
            if($error==1){
                echo("<p class='errore'>");
                echo("Inserisci una data valida!");
                echo("</p>");}}



        if($error==0){
            $query = "INSERT INTO CLIENTE (Codice_Fiscale, Nome, Cognome, Data_Nascita, Età, Pass)
            VALUES ('$codice_fiscale','$nome','$cognome','$data',$eta,'$password')";

            $res = mysqli_query($conn, $query);
            if ($res) {
                $_SESSION["codice_fiscale"] = $_POST['codice_fiscale'];
                mysqli_close($conn);
                header("Location: iscrizione_abbonamento.php");
                 exit;} 
            else {
                $error++;
                echo("<p class='errore'>");
                echo("Errore di connessione al database!");
                echo("</p>");}
        }

    }




?>

<html>
    <head>
    <meta charset="utf-8">
    <title>Daniele Zinghirino: Homework1</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Dela+Gothic+One&display=swap" rel="stylesheet">
    <link href="style/form.css" rel="stylesheet" type="text/css">
    <script src="script/verifica_dati_iscrizione.js" defer></script>

        <title>Iscriviti</title>
    </head>
    <body>
        <main>
        <section>
            <h1>Iscriviti</h1>
            <div id="allineamento">
            <form name='iscrizione' method='post'>
                <div class="names">
                    <div class="nome">
                        <div><label for='nome'>Nome</label></div>
                        <div><input type='text' name='nome' <?php if(isset($_POST["nome"])){echo "value=".$_POST["nome"];} ?> ></div>

                    </div>
                    <div class="cognome">
                        <div><label for='cognome'>Cognome</label></div>
                        <div><input type='text' name='cognome' <?php if(isset($_POST["cognome"])){echo "value=".$_POST["cognome"];} ?> ></div>

                    </div>
                </div>
                <div class="codice_fiscale">
                    <div><label for='codice_fiscale'>Codice fiscale</label></div>
                    <div><input type='text' name='codice_fiscale' <?php if(isset($_POST["codice_fiscale"])){echo "value=".$_POST["codice_fiscale"];} ?>></div>

                </div>
                <div class="giorno_nascita">
                    <div><label for='giorno_nascita'>Giorno di nascita</label></div>
                    <div><input type='number' name='giorno_nascita' min="1" max="31"<?php if(isset($_POST["giorno_nascita"])){echo "value=".$_POST["giorno_nascita"];} ?>></div>
                </div>
                <div class="mese_nascita">
                    <div><label for='mese_nascita'>Mese di nascita</label></div>
                    <div><input type='number' name='mese_nascita' min="1" max="12"<?php if(isset($_POST["mese_nascita"])){echo "value=".$_POST["mese_nascita"];} ?>></div>
                </div> 
                <div class="anno_nascita">
                    <div><label for='anno_nascita'>Anno di nascita</label></div>
                    <div><input type='number' name='anno_nascita' min="1931" max="2007" <?php if(isset($_POST["anno_nascita"])){echo "value=".$_POST["anno_nascita"];} ?>></div>
                </div>
                <div class="password">
                    <div><label for='password'>Password</label></div>
                    <div><input type='password' name='password' <?php if(isset($_POST["password"])){echo "value=".$_POST["password"];} ?>></div>

                </div>
                <div class="confirm_password">
                    <div><label for='confirm_password'>Conferma Password</label></div>
                    <div><input type='password' name='confirm_password' <?php if(isset($_POST["confirm_password"])){echo "value=".$_POST["confirm_password"];} ?>></div>

                </div>
                <div class="submit">
                    <input type='submit' value="Registrati" id="submit">
                </div>
            </form>
            <div class="signup">Hai un account? <a href="login.php">Accedi</a>
            </div>
            <div><a href="home.php">Indietro</a>
            </div>
        </section>
        </main>
    </body>
</html>